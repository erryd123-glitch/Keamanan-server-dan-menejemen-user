LMS Keamanan Server & Manajemen User
1. Buka index.html di browser. Login demo guru: username guru, password 123. Untuk siswa, username adalah nama depan (huruf kecil) dan password adalah nomor absen dua digit (01–36).
2. Template impor soal: Excel kolom Pertanyaan,A,B,C,D,Kunci atau Word berisi pertanyaan, opsi A-D, dan Kunci.
3. database/schema.sql berisi struktur 5 tabel MySQL (users, materi, soal, hasil, progress), dapat diimpor melalui phpMyAdmin.
4. Aplikasi HTML menyimpan data di localStorage browser; database SQL merupakan skema untuk integrasi backend.
5. Tema diperbarui menjadi Digital Corner glassmorphism cyan/teal dengan latar blur dan panel transparan.
Catatan: akun demo dan kata sandi sederhana hanya untuk uji coba lokal. Ganti sebelum penggunaan nyata.


PERBAIKAN IMPOR DATABASE
- File database/schema.sql telah direvisi agar tidak gagal jika tabel users/materi/soal sudah ada.
- Impor ulang tidak menghapus tabel atau data yang sudah ada.
- Pilih database yang benar (misalnya db_lms_tjkt) di phpMyAdmin sebelum membuka tab Import.
- CREATE TABLE IF NOT EXISTS tidak memperbaiki struktur tabel lama yang berbeda; bila aplikasi tetap error setelah impor, kirim pesan error terbaru.


PEMBARUAN DATA SISWA DAN MENU LOGIN
- Daftar 36 siswa dari foto ditambahkan otomatis saat aplikasi dibuka.
- Username siswa memakai nama depan (huruf kecil); password siswa mengikuti nomor absen pada daftar (01–36).
- Guru masuk dengan username guru, password 123. Siswa memilih peran Siswa, memakai nama depan dan password nomor absen dua digit.
- Data siswa digabungkan ke localStorage yang sudah ada tanpa menghapus akun/hasil/progress lama.
- Menu dirender dengan penanganan error agar kegagalan menu dapat menampilkan pesan, bukan layar kosong.


Revisi terbaru: tema Digital Corner cyan/teal dengan efek frosted-glass blur; menu Pojok Digital diperbarui; username siswa menggunakan nama depan dan password sesuai nomor absen (01–36). Menu Data Murid menampilkan password/nomor absen dan Reset PW mengembalikan password ke nomor absen.
