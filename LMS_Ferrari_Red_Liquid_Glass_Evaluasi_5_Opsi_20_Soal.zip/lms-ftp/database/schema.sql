-- Skema database LMS Keamanan Server dan Manajemen User (MySQL/MariaDB)
-- Aman diimpor ulang: tidak menghapus tabel/data; tabel yang sudah ada dilewati.
-- Jika ingin memakai db_lms_tjkt, pilih database tersebut di phpMyAdmin sebelum impor.
-- Catatan: CREATE TABLE IF NOT EXISTS tidak mengubah struktur tabel lama yang berbeda.
-- Jalankan impor setelah memilih database tujuan di phpMyAdmin.

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  role ENUM('guru','murid') NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS materi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(150) NOT NULL,
  deskripsi VARCHAR(255),
  isi TEXT
);
CREATE TABLE IF NOT EXISTS soal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pertanyaan TEXT NOT NULL,
  a VARCHAR(255), b VARCHAR(255), c VARCHAR(255), d VARCHAR(255), e VARCHAR(255),
  kunci ENUM('A','B','C','D','E') NOT NULL,
  sumber VARCHAR(100) DEFAULT 'manual'
);
CREATE TABLE IF NOT EXISTS hasil (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  nilai INT NOT NULL,
  benar INT NOT NULL,
  total INT NOT NULL,
  tanggal DATE NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS progress (
  user_id INT NOT NULL,
  materi_id INT NOT NULL,
  PRIMARY KEY (user_id, materi_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (materi_id) REFERENCES materi(id) ON DELETE CASCADE
);

INSERT IGNORE INTO users (nama,role,username,password) VALUES
('Dina Nurfitasari','guru','guru','123'),
('Andi Pratama','murid','murid','123');
UPDATE users SET nama='Dina Nurfitasari' WHERE role='guru' AND username='guru';
-- Data materi awal hanya ditambahkan jika judul belum ada
INSERT INTO materi (judul, deskripsi) SELECT 'Dasar Keamanan Server', 'Prinsip perlindungan server, data, dan akses.' WHERE NOT EXISTS (SELECT 1 FROM materi WHERE judul = 'Dasar Keamanan Server');
INSERT INTO materi (judul, deskripsi) SELECT 'Hardening Sistem Operasi Server', 'Konfigurasi sistem yang aman dan pengurangan celah.' WHERE NOT EXISTS (SELECT 1 FROM materi WHERE judul = 'Hardening Sistem Operasi Server');
INSERT INTO materi (judul, deskripsi) SELECT 'Firewall dan Pembaruan Keamanan', 'Pengaturan lalu lintas jaringan dan patch keamanan.' WHERE NOT EXISTS (SELECT 1 FROM materi WHERE judul = 'Firewall dan Pembaruan Keamanan');
INSERT INTO materi (judul, deskripsi) SELECT 'Manajemen User dan Hak Akses', 'Pengelolaan akun, peran, dan prinsip least privilege.' WHERE NOT EXISTS (SELECT 1 FROM materi WHERE judul = 'Manajemen User dan Hak Akses');
INSERT INTO materi (judul, deskripsi) SELECT 'Autentikasi, Kata Sandi, dan MFA', 'Autentikasi kuat dan perlindungan kredensial.' WHERE NOT EXISTS (SELECT 1 FROM materi WHERE judul = 'Autentikasi, Kata Sandi, dan MFA');
INSERT INTO materi (judul, deskripsi) SELECT 'Audit Log, Backup, dan Respons Insiden', 'Pemantauan, pemulihan, dan penanganan insiden.' WHERE NOT EXISTS (SELECT 1 FROM materi WHERE judul = 'Audit Log, Backup, dan Respons Insiden');
-- Bank soal awal hanya ditambahkan jika pertanyaan belum ada
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa tujuan utama keamanan server?', 'Mempercepat tampilan halaman saja', 'Melindungi sistem dan data dari akses tidak sah', 'Menghapus semua akun pengguna', 'Membuka seluruh port jaringan', 'Mengganti wallpaper server', 'B' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa tujuan utama keamanan server?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Prinsip least privilege berarti...', 'Semua user menjadi administrator', 'Izin diberikan sebanyak mungkin', 'Pengguna hanya diberi izin yang diperlukan', 'Semua akun memakai satu kata sandi', 'Semua pengguna bebas memasang aplikasi', 'C' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Prinsip least privilege berarti...');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa fungsi firewall pada server?', 'Mengatur lalu lintas jaringan berdasarkan aturan', 'Membuat backup otomatis selalu', 'Mengganti sistem operasi', 'Menyimpan kata sandi dalam teks biasa', 'Menaikkan kecepatan CPU', 'A' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa fungsi firewall pada server?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Tindakan yang tepat untuk akun pegawai yang sudah keluar adalah...', 'Membiarkannya aktif', 'Mengganti nama akun saja', 'Membagikan akunnya kepada pegawai lain', 'Menonaktifkan akun dan meninjau aksesnya', 'Memberinya hak administrator permanen', 'D' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Tindakan yang tepat untuk akun pegawai yang sudah keluar adalah...');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Mengapa pembaruan keamanan penting?', 'Agar semua port terbuka', 'Untuk memperbaiki kerentanan yang diketahui', 'Agar kata sandi tidak diperlukan', 'Untuk menonaktifkan pencatatan log', 'Supaya backup tidak diperlukan', 'B' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Mengapa pembaruan keamanan penting?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa praktik terbaik untuk akun administrator?', 'Dipakai bersama seluruh tim', 'Digunakan untuk semua aktivitas harian', 'Dilindungi MFA dan digunakan hanya saat diperlukan', 'Kata sandinya ditempel di server', 'Menggunakan kata sandi yang sama dengan semua akun', 'C' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa praktik terbaik untuk akun administrator?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Informasi apa yang penting dicatat dalam audit log?', 'Login dan perubahan hak akses', 'Warna tema aplikasi', 'Ukuran monitor pengguna', 'Daftar film pengguna', 'Jenis makanan pengguna', 'A' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Informasi apa yang penting dicatat dalam audit log?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Backup yang baik harus...', 'Disimpan hanya di server yang sama tanpa perlindungan', 'Tidak pernah diuji', 'Dapat diakses semua pengguna', 'Dilakukan berkala dan diuji pemulihannya', 'Menghapus salinan lama setiap hari tanpa kebijakan', 'D' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Backup yang baik harus...');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Saat menemukan indikasi server disusupi, langkah awal yang tepat adalah...', 'Menghapus semua bukti log', 'Mengikuti prosedur insiden dan mengisolasi sistem bila diperlukan', 'Membagikan kredensial ke semua orang', 'Membiarkan sistem tanpa pemeriksaan', 'Mematikan semua sistem tanpa koordinasi atau pencatatan', 'B' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Saat menemukan indikasi server disusupi, langkah awal yang tepat adalah...');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Mengapa setiap pengguna sebaiknya memiliki akun sendiri?', 'Agar aktivitas dapat diaudit dan tanggung jawab jelas', 'Agar semua orang punya hak admin', 'Supaya kata sandi boleh dibagikan', 'Agar log tidak dibutuhkan', 'Agar semua orang menggunakan sesi yang sama', 'A' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Mengapa setiap pengguna sebaiknya memiliki akun sendiri?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa langkah paling aman saat membuat akun pengguna baru?', 'Gunakan akun admin bersama', 'Berikan semua hak akses terlebih dahulu', 'Gunakan nama akun yang sama untuk semua orang', 'Bagikan kata sandi lewat grup umum', 'Verifikasi kebutuhan, buat akun unik, dan beri hak minimum', 'E' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa langkah paling aman saat membuat akun pengguna baru?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Bagaimana cara menyimpan kata sandi pengguna pada aplikasi dengan aman?', 'Dalam file teks biasa', 'Di lembar kerja yang dapat dibuka semua staf', 'Dengan hash kata sandi yang kuat dan salt', 'Di dalam nama pengguna', 'Di log server agar mudah dicari', 'C' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Bagaimana cara menyimpan kata sandi pengguna pada aplikasi dengan aman?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Kapan hak akses pengguna perlu ditinjau?', 'Hanya ketika server rusak', 'Secara berkala dan saat peran atau pekerjaan berubah', 'Tidak perlu ditinjau setelah dibuat', 'Setiap pengguna meminta akses admin', 'Hanya setelah aplikasi dihapus', 'B' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Kapan hak akses pengguna perlu ditinjau?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa kegunaan autentikasi multi-faktor (MFA)?', 'Menghapus kebutuhan semua akun', 'Membuat semua pengguna menjadi admin', 'Mengganti fungsi firewall', 'Menambah lapisan verifikasi selain kata sandi', 'Membagikan kode masuk antar pengguna', 'D' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa kegunaan autentikasi multi-faktor (MFA)?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa yang sebaiknya dilakukan terhadap akun yang tidak lagi digunakan?', 'Nonaktifkan atau hapus sesuai kebijakan dan audit aksesnya', 'Biarkan aktif selamanya', 'Gunakan sebagai akun bersama', 'Ubah menjadi akun administrator', 'Publikasikan kata sandinya', 'A' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa yang sebaiknya dilakukan terhadap akun yang tidak lagi digunakan?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Mengapa akses SSH administrator sebaiknya dibatasi?', 'Agar server tidak dapat diperbarui', 'Agar semua pengguna bisa masuk', 'Untuk mengurangi permukaan serangan dan akses yang tidak perlu', 'Agar log login berhenti dibuat', 'Untuk membuka semua port jaringan', 'C' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Mengapa akses SSH administrator sebaiknya dibatasi?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa tindakan yang tepat jika mendeteksi banyak percobaan login gagal?', 'Matikan audit log', 'Abaikan karena pasti normal', 'Kirim kata sandi ke pengguna lain', 'Hapus akun seluruh pengguna tanpa pemeriksaan', 'Periksa log, terapkan pembatasan login, dan investigasi sumbernya', 'E' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa tindakan yang tepat jika mendeteksi banyak percobaan login gagal?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Apa tujuan pemisahan akun administrator dan akun harian?', 'Agar akun harian selalu memiliki hak penuh', 'Mengurangi risiko jika aktivitas harian atau akun biasa disalahgunakan', 'Supaya tidak perlu MFA', 'Agar semua tindakan tidak tercatat', 'Agar kata sandi bisa digunakan bersama', 'B' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Apa tujuan pemisahan akun administrator dan akun harian?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Bagaimana sebaiknya izin folder tugas siswa pada server diatur?', 'Semua siswa dapat membaca dan mengubah semua folder', 'Semua folder dibuat publik', 'Gunakan satu akun untuk seluruh kelas', 'Setiap siswa hanya dapat mengakses folder sesuai kewenangannya', 'Nonaktifkan autentikasi folder', 'D' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Bagaimana sebaiknya izin folder tugas siswa pada server diatur?');
INSERT INTO soal (pertanyaan,a,b,c,d,e,kunci) SELECT 'Mengapa log keamanan perlu dilindungi dari perubahan?', 'Agar bukti aktivitas tetap dapat dipercaya saat audit atau investigasi', 'Agar kapasitas disk cepat penuh', 'Supaya pengguna dapat menghapus jejaknya', 'Agar server tidak memerlukan backup', 'Agar semua pengguna bisa mengedit log', 'A' WHERE NOT EXISTS (SELECT 1 FROM soal WHERE pertanyaan = 'Mengapa log keamanan perlu dilindungi dari perubahan?');
